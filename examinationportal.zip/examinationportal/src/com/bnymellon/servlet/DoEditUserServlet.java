package com.bnymellon.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnymellon.dao.implementation.UserAccountDaoImplementation;
import com.bnymellon.dao1.UserAccountDao;
import com.bnymellon.model.UserAccount;
@WebServlet(urlPatterns = { "/doEditUser" })
public class DoEditUserServlet extends HttpServlet {
	private static final long serialVersionUID = 4645721142572801104L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();

	public DoEditUserServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String loginId = (String) request.getParameter("username");
		String password = (String) request.getParameter("password");
		String firstname = (String) request.getParameter("firstname");
		String lastname = (String) request.getParameter("lastname");
		String role = (String) request.getParameter("role");
		
		UserAccount editUser = new UserAccount(loginId, password,firstname,lastname,role);
		System.out.println(editUser);
		userDao.update3(loginId, editUser);
		
		response.sendRedirect(request.getContextPath() + "/studentTasks.jsp");

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}