package com.bnymellon.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bnymellon.dao.implementation.UserAccountDaoImplementation;
import com.bnymellon.dao1.UserAccountDao;
import com.bnymellon.model.Question;
import com.bnymellon.model.UserAccount;
import com.bnymellon.utils.ConnectionFactory;
import com.bnymellon.utils.DBUtils;
import com.bnymellon.utils.QueryConstants;

/**
 * Servlet implementation class QuizServlet
 */
@WebServlet("/question")
public class QuizServlet extends HttpServlet {
	
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;
	
	private static final long serialVersionUID = 1L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuizServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		List<Question> list = (List<Question>)(session.getAttribute("userList3"));
		int size = 40;
				//Integer.parseInt((String) request.getAttribute("number"));
		List<String> listA = new ArrayList<String>();
		String[] answerGiven=new String[size];
		for(int i=1;i<=size;i++)
		{
			listA.add(request.getParameter("radio"+i));
			answerGiven[i-1]=request.getParameter("radio"+i);
		}
	for(String i : listA)
	{
		System.out.println(i);
		
	}
	int count=0;
	int marks=0;
	for(Question q:list)
	{
		System.out.println("Hello I am here");
		if(q.getCorrect().equals(answerGiven[count]))
		{
			marks++;
			System.out.println("inside validation");
		}
		System.out.println("--------------");
		System.out.println(q.getCorrect());
		System.out.println("-------------");
		count++;
	}
	int total=marks*5;
	System.out.println(total);
	session.setAttribute("mark", total);
	int percentage=(total*100)/50;
	
	session.setAttribute("percentage", percentage);
	
	
	System.out.println(percentage);
	String result=null;
	if(percentage>=60)
	{
		result="passed";
		System.out.println(result);
		
	}
	else
		result="failed";
		System.out.println(result);
	
	session.setAttribute("result", result);
	
String username=(String) request.getSession().getAttribute("username");

	try {
		connection = ConnectionFactory.getConnection();
		connection.setAutoCommit(false);

		preparedStatment = connection.prepareStatement("insert into xbbnhmb_result11 values(?,?)");

		//preparedStatment.setString(1, username);
	
		preparedStatment.setString(1, username);
		preparedStatment.setInt(2, marks);
	
		
		

		// Execute statement.
		int rowsInserted = preparedStatment.executeUpdate();

		if (rowsInserted > 0) {
			System.out.println("A new account was saved successfully!");
			connection.commit();
		}

	} catch (SQLException e) {
		System.out.println("SQLException in save() method");
		e.printStackTrace();
		try {
			connection.rollback();
		} catch (SQLException e1) {
			System.out.println("Rollback Exception in save() method");
			e1.printStackTrace();
		}
	} finally {
		DBUtils.close(preparedStatment);
		DBUtils.close(connection);
	}
	
	RequestDispatcher dispatcher = request.getServletContext()
			.getRequestDispatcher("/viewresult.jsp");
	
	dispatcher.forward(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
doGet(request,response);
		
	}

}
