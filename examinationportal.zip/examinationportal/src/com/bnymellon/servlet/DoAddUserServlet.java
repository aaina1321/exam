package com.bnymellon.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnymellon.dao.implementation.UserAccountDaoImplementation;
import com.bnymellon.dao1.UserAccountDao;
import com.bnymellon.model.UserAccount;

@WebServlet(urlPatterns = { "/doAddUser" })
public class DoAddUserServlet extends HttpServlet {

    
                private static final long serialVersionUID = 4645721142572801105L;
                private UserAccountDao userDao = new UserAccountDaoImplementation();

                public DoAddUserServlet() {
                                super();
                }

                @Override
                protected void doGet(HttpServletRequest request, HttpServletResponse response)
                                                throws ServletException, IOException {

                	            String username = (String)request.getParameter("username");
                                String password = (String)request.getParameter("password");
                                String firstname=(String)request.getParameter("firstname");
                                String lastname=(String)request.getParameter("lastname");
                                String role = (String)request.getParameter("role");
                            
                                UserAccount newUser = new UserAccount(username,password,firstname,lastname,role);
                                String errorString = null;
                                
                                String regex = "^[a-zA-Z][0-9]{3}$";
                              
                                if (username == null || !username.matches(regex)) {
                                                errorString = "username is the string literal ^[a-zA-Z][0-9]{3}$ !";
                                                
                                }
                                
                                        
                                System.out.println(errorString);
                                if (errorString == null) {
                                	
                                                userDao.save(newUser);
                                }

                                // Store infomation to request attribute, before forward to views.
                                request.setAttribute("errorString", errorString);
                                request.setAttribute("newUser", newUser);

                                // If error
                                if (errorString != null) {
                                	
                                                RequestDispatcher dispatcher = request.getServletContext()
                                                                                .getRequestDispatcher("/studentLogin.jsp");
                                                dispatcher.forward(request, response);
                                }

                                // If no error.
                                // Redirect to the product listing page.
                                else {
                               
                                                request.setAttribute("errorString", "Successfully Registered.");                
                                                response.sendRedirect(request.getContextPath() + "/studentLogin.jsp");
                                                
                                }

                }

                @Override
                protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                                throws ServletException, IOException {
                                doGet(request, response);
                }

}
