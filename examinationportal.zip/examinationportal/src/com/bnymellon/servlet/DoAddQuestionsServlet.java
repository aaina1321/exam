package com.bnymellon.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnymellon.dao.implementation.QuestionDaoImplementation;
import com.bnymellon.dao.implementation.UserAccountDaoImplementation;
import com.bnymellon.dao1.QuestionDao;
import com.bnymellon.dao1.UserAccountDao;
import com.bnymellon.model.Question;
import com.bnymellon.model.UserAccount;

@WebServlet(urlPatterns = { "/doAddQues" })
public class DoAddQuestionsServlet extends HttpServlet {

    
                private static final long serialVersionUID = 4645721142572801105L;
                private QuestionDao quesDao = new QuestionDaoImplementation();

                public DoAddQuestionsServlet() {
                                super();
                }

                @Override
                protected void doGet(HttpServletRequest request, HttpServletResponse response)
                                                throws ServletException, IOException {

                	            String question = (String)request.getParameter("question");
                                String option1 = (String)request.getParameter("option1");
                                String option2=(String)request.getParameter("option2");
                                String option3=(String)request.getParameter("option3");
                                String option4 = (String)request.getParameter("option4");
                                String correct = (String)request.getParameter("correct");
                                
                             
                                System.out.println(question);
                                System.out.println(option1);
                                System.out.println(option2);
                                System.out.println(option3);
                                System.out.println(option4); 
                                System.out.println(correct);
                                
                                
                                
                                Question newUser = new Question(question,option1,option2,option3,option4,correct);
                                String errorString = null;
                                

                              
                                if (question== null) {
                                                errorString = "enter question!";
                                                
                                }
                                
                                        
                                System.out.println(errorString);
                                if (errorString == null) {
                                	
                                                quesDao.save(newUser);
                                }

                                // Store infomation to request attribute, before forward to views.
                                request.setAttribute("errorString", errorString);
                                request.setAttribute("newUser", newUser);

                                // If error
                                if (errorString != null) {
                                	
                                                RequestDispatcher dispatcher = request.getServletContext()
                                                                                .getRequestDispatcher("/adminTasks.jsp");
                                                dispatcher.forward(request, response);
                                }

                                // If no error
                                // Redirect to the product listing page.
                                else {
                               
                                                request.setAttribute("errorString", "Successfully Registered.");                
                                                response.sendRedirect(request.getContextPath() + "/adminTasks.jsp");
                                                
                                }

                }

                @Override
                protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                                throws ServletException, IOException {
                                doGet(request, response);
                }

}
