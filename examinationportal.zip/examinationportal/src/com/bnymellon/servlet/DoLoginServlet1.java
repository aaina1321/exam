
package com.bnymellon.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.SQLException;

import com.bnymellon.dao.implementation.UserAccountDaoImplementation;
import com.bnymellon.dao1.UserAccountDao;
import com.bnymellon.model.UserAccount;

@WebServlet(urlPatterns = { "/validate" })
public class DoLoginServlet1 extends HttpServlet {


                private static final long serialVersionUID = 5590990410746775329L;
                private UserAccountDao userDao = new UserAccountDaoImplementation();

                public DoLoginServlet1() {
                                super();
                }

                @Override
                protected void doGet(HttpServletRequest request, HttpServletResponse response)
                                                throws ServletException, IOException {

                                String userName = request.getParameter("userName");
                                String password = request.getParameter("password");
                                System.out.println(userName);
                                System.out.println(password);
                                UserAccount user = null;
                                boolean hasError = false;
                                String errorString = null;

                                if (userName == null || password == null || userName.length() == 0 || password.length() == 0) {
                                                hasError = true;
                                                errorString = "Required username and password!";
                                                System.out.println(errorString);
                                } else {

                                                user = userDao.findUser(userName, password);
                                                System.out.println("user");
                                                System.out.println(user);
                                                if (user == null) {
                                                                hasError = true;
                                                                errorString = "User Name or password invalid";
                                                                System.out.println(errorString);               
                                                                request.setAttribute("errorString", "Unknown login, please try again.");               
                                                
                                                }

                                }
                                // If error, forward to /WEB-INF/views/_login.jsp
                                if (hasError) {
                                                user = new UserAccount();
                                                user.setUserName(userName);
                                                user.setPassword(password);
                                                // Store information in request attribute, before forward.
                                                request.setAttribute("errorString", errorString);
                                                request.setAttribute("user", user);

                                                // Forward to /WEB-INF/views/_login.jsp
                                                getServletContext().getRequestDispatcher("/studentLogin.jsp").forward(request, response);
                                }

                                // If no error
                                // Store user information in Session
                                // And redirect to correct home page.
                                else {
                                                HttpSession session = request.getSession(true);
                                                session.setAttribute("userIs", user);
                                                session.setAttribute("username", user.getUserName());

                                                
                                                
                                                if (user.getRole().equals("student")) {
                                                                // Redirect to userInfo page.
                                                                try{
                                                                UserAccountDao Emp=new UserAccountDaoImplementation();
                                                                
                                                                UserAccount checkDetail=Emp.getDetail(userName);
                                                               
//                                                            request.setAttribute("checkDetail",checkDetail);
                                                                  session.setAttribute("checkDetail",checkDetail); 
                                                                  


                                                                }
                                                                catch(SQLException e)
                                                                {System.out.println(e.getMessage());}
                                                                getServletContext().getRequestDispatcher("/studentTasks.jsp").forward(request, response);
                                                                
                                                }
                                                else if (user.getRole().equals("admin")) {
                                                	 try{
                                                         UserAccountDao Emp=new UserAccountDaoImplementation();
                                                      
                                                         UserAccount checkDetail=Emp.getDetail(userName);
                                                      
//                                                     request.setAttribute("checkDetail",checkDetail);
                                                           session.setAttribute("checkDetail",checkDetail); 
                                                          


                                                         }
                                                         catch(SQLException e)
                                                         {System.out.println(e.getMessage());}
                                                         getServletContext().getRequestDispatcher("/adminTasks.jsp").forward(request, response);
                                                         
                                         }
                                                	
                                              
                                    
                                    else
                                    {
                                                    
                                    	 getServletContext().getRequestDispatcher("/studentLogin.jsp").forward(request, response);                         
                                                    
                                    }
                                }
                                
                
                                
                }

                @Override
                protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                                throws ServletException, IOException {
                                doGet(request, response);
                }

}













