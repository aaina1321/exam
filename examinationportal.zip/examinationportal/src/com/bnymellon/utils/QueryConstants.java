package com.bnymellon.utils;



	public class QueryConstants 
	{
	       public static final String INSERT_USER = "INSERT INTO XBBNHMB_SignIn1 VALUES(?,?,?,?,?)";
	       public static final String UPDATE_USER = "UPDATE XBBNHMB_SignIn1 SET username=?,firstname=?,lastname=?,role=? WHERE username=?";
	       public static final String SELECT_USER = "SELECT * FROM XBBNHMB_SignIn1 WHERE username=? AND password=?";
	       public static final String SELECT_USER_BY_ID = "SELECT * FROM XBBNHMB_SignIn1 WHERE username=?";
	       public static final String SELECT_ALL_USER = "SELECT * FROM XBBNHMB_SignIn1 ORDER BY role";
	       public static final String SELECT_ALL_USER1 = "SELECT * FROM XBBNHMB_QUESTIONS1";
	       public static final String INSERT_USER1 = "INSERT INTO XBBNHMB_QUESTIONS1 VALUES(?,?,?,?,?,?)";
	       public static final String SELECT_ALL_USER2 = "SELECT * FROM XBBNHMB_RESULT11"; 
	       

}