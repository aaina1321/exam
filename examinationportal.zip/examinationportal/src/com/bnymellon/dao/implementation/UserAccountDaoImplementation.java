package com.bnymellon.dao.implementation;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bnymellon.dao1.UserAccountDao;
import com.bnymellon.model.UserAccount;
import com.bnymellon.utils.ConnectionFactory;
import com.bnymellon.utils.DBUtils;
import com.bnymellon.utils.QueryConstants;



public class UserAccountDaoImplementation implements UserAccountDao{

                private Connection connection;
                private Statement statement;
                private PreparedStatement preparedStatment;

                public UserAccountDaoImplementation() {
                }
                @Override
                public void save(UserAccount user) {
                	   
                                try {
                                                connection = ConnectionFactory.getConnection();
                                                connection.setAutoCommit(false);

                                                preparedStatment = connection.prepareStatement(QueryConstants.INSERT_USER); //XBBNHMB_SignIn1
                                               
                                                preparedStatment.setString(1, user.getUserName());
                                                preparedStatment.setString(2, user.getPassword());
                                                preparedStatment.setString(3, user.getFirstName());
                                                preparedStatment.setString(4, user.getLastName());
                                                preparedStatment.setString(5, user.getRole());
                                       
                                                // Execute statement.
                                                int rowsInserted = preparedStatment.executeUpdate();

System.out.println(rowsInserted);
                                                if (rowsInserted > 0) {
                                                                System.out.println("A new account was saved successfully!");
                                                                connection.commit();
                                                }

                                } catch (SQLException e) {
                                                System.out.println("SQLException in save() method");
                                                e.printStackTrace();
                                                try {
                                                                connection.rollback();
                                                } catch (SQLException e1) {
                                                                System.out.println("Rollback Exception in save() method");
                                                                e1.printStackTrace();
                                                }
                                } finally {
                                                DBUtils.close(preparedStatment);
                                                DBUtils.close(connection);
                                }

                }

                  
                
                @Override
                public UserAccount findUser(String userId, String userPass) {

                    
                	
                                ResultSet rs = null;
                                UserAccount found = null;

                                try {
                                                connection = ConnectionFactory.getConnection();
                                                preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER); //XBBNHMB_SignIn1
                                                preparedStatment.setString(1, userId);
                                                preparedStatment.setString(2, userPass);
                                                rs = preparedStatment.executeQuery();
                                                if (rs.next()) {
                                                                found = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5));
                                                                
                                                }

                                } catch (SQLException e) {
                                                System.out.println("SQLException in get() method");
                                                e.printStackTrace();
                                } finally {
                                                DBUtils.close(rs);
                                                DBUtils.close(preparedStatment);
                                                DBUtils.close(connection);
                                }
                                return found;
                }
                
                @Override
                public UserAccount findUser(String userId) {

                                ResultSet rs = null;
                                UserAccount found = null;

                                try {
                                                connection = ConnectionFactory.getConnection();
                                                preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER_BY_ID); //XBBNHMB_SignIn1
                                                preparedStatment.setString(1, userId);
                                                rs = preparedStatment.executeQuery();
                                                if (rs.next()) {
                                                                found = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5));
                                                }

                                } catch (SQLException e) {
                                                System.out.println("SQLException in get() method");
                                                e.printStackTrace();
                                } finally {
                                                DBUtils.close(rs);
                                                DBUtils.close(preparedStatment);
                                                DBUtils.close(connection);
                                }
                                return found;
                }

                @Override
                public List<UserAccount> allUsers() throws SQLException {

                                ResultSet rs = null;
                                List<UserAccount> foundList = new ArrayList<UserAccount>();
                                UserAccount currentUser = null;
                                try {
                                                connection = ConnectionFactory.getConnection();
                                                preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER); //XBBNHMB_SignIn1
                                                rs = preparedStatment.executeQuery();
                                                while (rs.next()) {
                                                                currentUser  = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5));
                                                                foundList.add(currentUser);
                                                }
                                } catch (SQLException e) {
                                                System.out.println("SQLException in get() method");
                                                e.printStackTrace();
                                } finally {
                                                DBUtils.close(rs);
                                                DBUtils.close(preparedStatment);
                                                DBUtils.close(connection);
                                }
                                return foundList;
                }

                public UserAccount getDetail(String userName) throws SQLException {

                    String strr = "'"+userName+"'";
                    String query = "SELECT * FROM XBBNHMB_SignIn1 WHERE username ="+strr;
                    
                    ResultSet rs = null;
                    UserAccount account = null;
                    
                    try {
                           connection = ConnectionFactory.getConnection();
                           statement = connection.createStatement();
                           rs = statement.executeQuery(query);
                           
                           if(rs.next()) {
                           
                                 account = new UserAccount();
                                 
                                 account.setUserName(rs.getString(1));
                                 account.setFirstName(rs.getString(3));
                                 account.setLastName(rs.getString(4));
                                 account.setRole(rs.getString(5));
                             
                                 System.out.println(account);
                           }
                           

                    } finally {
                           DBUtils.close(rs);
                           DBUtils.close(statement);
                           DBUtils.close(connection);
                    }
                    return account;
             }
             
             

                @Override
                public void update3(String userId, UserAccount newUser) {

                       try {
                              connection = ConnectionFactory.getConnection();
                              connection.setAutoCommit(false);

                              preparedStatment = connection.prepareStatement(QueryConstants.UPDATE_USER); //XBBNHMB_SignIn1

                              preparedStatment.setString(1,userId);
                              System.out.println(newUser.getUserName());
                              
                              preparedStatment.setString(2, newUser.getFirstName());
                              System.out.println(newUser.getFirstName());
                              
                              preparedStatment.setString(3, newUser.getLastName());
                              System.out.println(newUser.getLastName());
                              
                              preparedStatment.setString(4, newUser.getRole());
                              System.out.println( newUser.getRole());
                              
                              preparedStatment.setString(5,userId);
                              System.out.println(userId);
                              
                              
                              // Execute statement.
                              int rowsUpdated = preparedStatment.executeUpdate();
                              System.out.println(rowsUpdated);
                              if (rowsUpdated > 0) {
                                    System.out.println("User " + userId + " was updated successfully!");
                                    connection.commit();
                              }

                       } catch (SQLException e) {
                              System.out.println("SQLException in update() method");
                              e.printStackTrace();
                              try {
                                    connection.rollback();
                              } catch (SQLException e1) {
                                    System.out.println("Rollback Exception in update() method");
                                    e1.printStackTrace();
                              }
                       } finally {
                              DBUtils.close(preparedStatment);
                              DBUtils.close(connection);
                       }

                }


                

}

