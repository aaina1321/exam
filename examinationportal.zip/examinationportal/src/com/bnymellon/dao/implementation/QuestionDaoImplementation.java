package com.bnymellon.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bnymellon.dao1.QuestionDao;
import com.bnymellon.model.Question;
import com.bnymellon.model.UserAccount;
import com.bnymellon.utils.ConnectionFactory;
import com.bnymellon.utils.DBUtils;
import com.bnymellon.utils.QueryConstants;

public class QuestionDaoImplementation implements QuestionDao {
	
	
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;
	
	@Override
	public List<Question> allUsers() throws SQLException {
		ResultSet rs = null;
		List<Question> foundList = new ArrayList<Question>();
		Question currentUser = null;
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER1); //XBBNHMB_QUESTIONS1
			rs = preparedStatment.executeQuery();
			while (rs.next()) {
				currentUser = new Question(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
				foundList.add(currentUser);
			}
		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return foundList;
	}



	
	
	
	


	public void save(Question user) {
		try {
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false); //turned off

			preparedStatment = connection.prepareStatement(QueryConstants.INSERT_USER1); //XBBNHMB_QUESTIONS1

			preparedStatment.setString(1, user.getQuestion());
			preparedStatment.setString(2, user.getOption1());
			preparedStatment.setString(3, user.getOption2());
			preparedStatment.setString(4, user.getOption3());
			preparedStatment.setString(5, user.getOption4());
			preparedStatment.setString(6, user.getCorrect());
			

			// Execute statement.
			int rowsInserted = preparedStatment.executeUpdate();

			if (rowsInserted > 0) {
				System.out.println("A new qustion was saved successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in save() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in save() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}






}
