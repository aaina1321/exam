package com.bnymellon.dao1;

import java.sql.SQLException;
import java.util.List;
import com.bnymellon.model.Question;
import com.bnymellon.model.UserAccount;

public interface QuestionDao {

	List<Question> allUsers() throws SQLException;
	void save(Question user);
	
}
