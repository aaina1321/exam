package com.bnymellon.dao1;
import java.sql.SQLException;
import java.util.List;

import com.bnymellon.model.UserAccount;

public interface UserAccountDao {
   
    

    void save(UserAccount user);

    UserAccount findUser(String userId, String userPass);
   
    List<UserAccount>allUsers() throws SQLException;

    UserAccount findUser(String userId);

    UserAccount getDetail(String userName) throws SQLException;
    
    void update3(String username, UserAccount newUSer);

}
