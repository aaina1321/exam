package com.bnymellon.lnd.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bnymellon.lnd.model.Emp;

public class EmpRowMapper implements RowMapper<Emp> {

	@Override
	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		Emp tempEmp = new Emp();
		tempEmp.setUserName(rs.getString(1));
		tempEmp.setPassword(rs.getString(2));	
		tempEmp.setFirstName(rs.getString(3));
		tempEmp.setLastName(rs.getString(4));
		tempEmp.setRole(rs.getString(5));
		return tempEmp;
	}

}
